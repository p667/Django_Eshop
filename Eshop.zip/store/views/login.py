from urllib import request
from store.models.customer import Customer
from django.views import View
from django.shortcuts import render
from django.contrib.auth.hashers import check_password
from store.models.customer import Customer
from django.shortcuts import redirect, HttpResponseRedirect


class Login(View):
    return_url = None
    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'login.html')
    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        print(email, password)
        try:
            customer = Customer.objects.get(email = email)
            print(customer)
            flag = check_password(password = password , encoded = customer.password)
            if flag:
                #print(flag,"MMMMMMMMMMMMMMM")
                #print(user.__dict__)
                # temp = {}
                # temp['email'] = customer.email
                # temp['studentId'] = customer.studentId
                # request.session['user'] = temp
                #return render(request,'index.html')
                request.session['customer'] = customer.id
                #request.session['email'] = customer.email
                #return redirect('homepage')
                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url = None
                    return redirect('homepage')
            else:
                return render(request,'login.html' , {'error' : 'Email or Password Invalid'})
        except:
            return render(request,'login.html' , {'error' : 'Email or Password Invalid'}) #redirect index from url name

def logout(request):
    request.session.clear()
    return redirect('login')
