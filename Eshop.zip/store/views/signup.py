from django.views import View
from django.shortcuts import render
from django.contrib.auth.hashers import make_password
from store.models.customer import Customer
from django.shortcuts import redirect




class Signup(View):
    def get(self,request):
        return render(request, 'signup.html')
    def post(self, request):
        postData = request.POST
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        #Validation

        value = {
            'first_name' : first_name,
            'last_name' : last_name,
            'phone'     :  phone,
            'email'      : email
        }





        error_message = None

        customer = Customer(first_name=first_name, last_name=last_name,phone=phone, email=email,password=password)


        if(not first_name):
            error_message = "First Name Required !"
        elif len(first_name) < 4:
            error_message = "First Name must be 4 char long or more"
        
        elif (not last_name):
            error_message= 'Last Name Required'
        elif len(last_name) < 4:
            error_message = 'Last Name must be 4 char long or more'
        elif (not phone) :
            error_message = 'Phone Number Required'
        elif len(phone) < 10 :
            error_message = "Phone Number must be 10 digits"
        elif (not password):
            error_message= "Password Required"
        elif len(password)< 6:
            error_message = "Password must be 6 char long"
        elif len(email)< 5:
            error_message = 'Email mustbe 5 char long'
        elif Customer.objects.filter(email = email).exists():
            error_message = 'Email Already Registered'
        elif Customer.objects.filter(phone=phone).exists():
            error_message= "Phone Number Already Registered" 
            
            
        
        #saving
        if not error_message:
            print(first_name,last_name,phone,email,password)
            customer.password = make_password(customer.password)
            #customer = Customer(first_name=first_name, last_name=last_name,phone=phone, email=email,password=password)


            customer.save()
            return redirect('homepage')
        else:
            data = {
                'error' : error_message,
                'vlaues' : value
            }
            return render(request, 'signup.html', data)
