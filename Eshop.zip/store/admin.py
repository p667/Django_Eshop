from unicodedata import category
from django.contrib import admin

#from store.models import customer
from .models.product import Product
from .models.category import Categorie
from .models.customer import Customer
from .models.orders import Order


class AdminProduct(admin.ModelAdmin):
    list_display = ['name','price','category']

class AdminCategorie(admin.ModelAdmin):
    list_display = ['name']

# Register your models here.
admin.site.register(Product, AdminProduct)

admin.site.register(Categorie, AdminCategorie)

admin.site.register(Customer)

admin.site.register(Order)

