import imp
from itertools import product
from statistics import mode
from unicodedata import category, name
from django.db import models
#from .product import Product

class Categorie(models.Model):
    name = models.CharField(max_length=20)


    @staticmethod
    def get_all_categories():
        return Categorie.objects.all()

    '''
    @staticmethod
    def get_all_categories_by_id(categoery_id):

        return Categorie.objects.filter(categoery = categoery_id)

    '''


    def __str__(self):
        return self.name
        